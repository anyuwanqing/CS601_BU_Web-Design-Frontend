

"""13.4 (Write/read data)
Write a program that writes 100 integers
created randomly into a file.
Integers are separated by a space in the file.
Read the data back from the file
and display the sorted data.
Your program should prompt the user to enter
a file- name.
If the file already exists, do not overwrite it.
Here is a sample run:
"""

import os.path
# import random
if os.path.isfile("ram_integer.txt"):
    print("ram_integer exists")
    print("reading it....")

    with open("ram_integer.txt", "r") as f:
        print(f.read())
    f.close()


else:
    filename = "ram_integer.txt"

    # create a new one
    with open(filename, "w") as f:
        print("The 100 random integers written are: ")
    for i in range(100):
        line = str(random.randint(1,100))
    f.write(line)
    f.write(" ")

    # reading
    with open(filename, "r") as f:
        print(f.read())
    f.close()





"""10.22"""
""""(Simulation: coupon collector’s problem) 
Coupon Collector is a classic statistics problem 
with many practical applications. 
The problem is to pick objects from a set of objects 
repeatedly and find out how many picks are needed 
for all the objects to be picked at least once. 
A variation of the problem is to pick cards
 from a shuffled deck of 52 cards repeatedly and find out 
 how many picks are needed before you see one of each suit. 
 Assume a picked card is placed back in the deck before picking another. 
 Write a program to simulate the number of picks needed to
  get four cards, one from each suit and display the four cards 
  picked (it is possi- ble a card may be picked twice). 
  Here is a sample run of the program:
"""


DECK_SIZE = 52
suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
ranks = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9",
             "10", "Jack", "Queen", "King"]

# default pick
num_picks = 0

deck = [x for x in range(1, DECK_SIZE)] # array of 1 ~ 52
print(deck)

# suit found is a boolean array representing 4 suits
suit_found = [False, False, False, False] ## club, diamound, hearts, and spades


# while not founding all suit == True
while not (suit_found[0] == True and suit_found[1] == True and suit_found[2] == True and suit_found[3] == True):
    num_picks += 1
    card_index = random.randint(1, DECK_SIZE) # 0 ~ 51
    print("card index " + str(card_index))
    suit = suits[card_index // 13 -1] # 0 1 2 3
    rank = ranks[card_index % 13]
    if suit == "Clubs":
        suit_found[0] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Diamonds":
        suit_found[1] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Hearts":
        suit_found[2] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )
    elif suit == "Spades":
        suit_found[3] = True
        print("Card num (1 ~ 52) #", card_index, "is ", rank, " of ", suit )

print("\nNumber of picks: ", num_picks)


"""10.29 (Game: hangman) 
Write a hangman game that randomly generates a word 
and prompts the user to guess one letter at a time, 
as shown in the sample run. Each letter in the word is 
displayed as an asterisk. When the user makes a correct guess, 
the actual letter is then displayed. When the user 
finishes a word, dis- play the number of misses and ask
 the user whether to continue playing. Create a list to store 
 the words, as follows:
"""

#import random

words_arr = ["that","good", "apple"]

def current_guess(word, guesses):
    ast_word = ""
    for char in word:
        if char in guesses:
            ast_word += char
        else:
            ast_word += "*"
    return ast_word


def play():
    play_again = True;
    first_round = True;

    while play_again:
        word = random.choice(words_arr)
        ast_word = ""
        for i in range(len(word)):
            ast_word += "*"
        print(ast_word)

        guesses = []

        guess_wrong = 0


        if play_again: # starting
            # while didn't guess the full word
            while "*" in current_guess(word, guesses):
                guess = input("Enter a letter in word " + current_guess(word,guesses) + ":")
                guesses.append(guess)
                if guess in guesses and guess in word:
                    print(guess + " is in the word")
                elif guess not in word:
                    print(guess + " is not in the word.")
                    guess_wrong += 1
                else:
                    guesses.append(guess)

            print("Congrat! You guess the word successfully")
            print("the word is " + word + ". You missed " + str(guess_wrong) + " times.")
            again = input("Do you want to play again? y or n ")
            if again == "n":
                play_again = False


play()


