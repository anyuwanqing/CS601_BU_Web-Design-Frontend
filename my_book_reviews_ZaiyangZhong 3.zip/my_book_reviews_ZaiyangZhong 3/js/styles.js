
class SelfIntro {
  constructor(name, school,content) {
    this.name = name;
    this.school = school;
    this.content = content;
  }


// this is class func
printIntroduction(){
    console.log("My name is ", this.name, ". I am from ", this.school, " and ", this.content)
    return ("My name is ", this.name, ". I am from ", this.school, " and ", this.content);
}

// another class func
loadSelfIntro(){


    document.getElementById("self_intro_content").innerHTML = this.printIntroduction();
        return this.printIntroduction()}

    }



$(document).ready(function(){

    $("#introduction").mouseover(function(){
    const s = new SelfIntro("Zaiyang", "BU", "I like reading, writing, and want to share my favorite books with you.");
    s.loadSelfIntro()

    });

   $("#title_huge").mouseover(function(){
   $("#title_huge").css("text-decoration", "underline");
   });
      $("#title_huge").mouseleave(function(){
      $("#title_huge").css("text-decoration", "none");
      });

  $("#theme").click(function(){
    $("body").css("background-color", "lightyellow");
  });

  var t1 = document.getElementById("theme");
  t1.addEventListener('mouseover', (event) => {
    $("#theme").css("color", "blue");
});

  var t1 = document.getElementById("theme");
  t1.addEventListener('mouseleave', (event) => {
    $("#theme").css("color", "black");
});


    $("#theme2").click(function(){
      $("body").css("background-color", "grey");
    });

  var t2 = document.getElementById("theme2");
  t2.addEventListener('mouseover', (event) => {
    $("#theme2").css("color", "blue");
});

  var t2 = document.getElementById("theme2");
  t2.addEventListener('mouseleave', (event) => {
    $("#theme2").css("color", "black");
});

    $("#theme3").click(function(){
      $("body").css("background-color", "lightblue");
    });

  var t3 = document.getElementById("theme3");
  t3.addEventListener('mouseover', (event) => {
    $("#theme3").css("color", "blue");
});

  var t3 = document.getElementById("theme3");
  t3.addEventListener('mouseleave', (event) => {
    $("#theme3").css("color", "black");
});


    $("#theme4").click(function(){
      $("body").css("background-color", "lightgreen");
    });
      var t4 = document.getElementById("theme4");
      t4.addEventListener('mouseover', (event) => {
        $("#theme4").css("color", "blue");
    });
          var t4 = document.getElementById("theme4");
          t4.addEventListener('mouseleave', (event) => {
            $("#theme4").css("color", "black");
        });

        $("#book_list1").mouseover(function(){
          $("#book_list1").css("text-decoration", "underline");
        });
         $("#book_list1").mouseleave(function(){
                  $("#book_list1").css("text-decoration", "none");
                });
                        $("#book_list2").mouseover(function(){
                          $("#book_list2").css("text-decoration", "underline");
                        });
                         $("#book_list2").mouseleave(function(){
                                  $("#book_list2").css("text-decoration", "none");
                                });

                                        $("#book_list3").mouseover(function(){
                                          $("#book_list3").css("text-decoration", "underline");
                                        });
                                         $("#book_list3").mouseleave(function(){
                                                  $("#book_list3").css("text-decoration", "none");
                                                });

    // theme functions

    function theme(){
    $("#theme").css("background-color", "black");
    }
    function theme2(){
        $("#theme").css("background-color", "black");
        }
    function theme3(){
        $("#theme").css("background-color", "black");
        }
        function theme4(){
            $("#theme").css("background-color", "black");
            }





    window.addEventListener("DOMContentLoaded", event => {


    const sqrt = function(a) {
        return a*a;
    }

    console.log("this is for function expression. squart root of 5 will be " + sqrt(5));



        });




function loadNewForm(){
  var book_title = $("#book-title").val();

  console.log(book_title)
  var book_content = $('#book-content').val();
  console.log(book_content)

  $("#new_post_heading").text(book_title);
  $("#new_post_content").text(book_content);

  // take inputs and change the content
}




    // function declaration

    function sum(a, b){
        const c = a+b;
        return c;
    }

// arrow function
const absValue = (number) => {
  if (number < 0) {
    return -number;
  }else{
  return number;
  }
  };

  console.log("this is for arrow function. absolute value for -10 and 5 are: " + absValue(-10) + "  " + absValue(5));




});



function showForm(){
    document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";

}



function submitForm(){
    console.log("submit is hit");
     var empty = ""
     var name = $('#form_name').val();
     console.log(name)
     var email = $('#form_email').val();
     console.log(email)
     var content = $('#form_content').val();

     // if content is not empty
     if (content != empty){
       $("#form_success").css("display", "block");
       const str = "submited message: " + "name: "+name+"; email: "+email+"; contact: "+content;
       alert(str);
     }
     else{
       alert("Error Input!")}
}









